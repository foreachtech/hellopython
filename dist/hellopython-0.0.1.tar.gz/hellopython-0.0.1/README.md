Hello world program in python3 
Dev by Le Tan Thang
